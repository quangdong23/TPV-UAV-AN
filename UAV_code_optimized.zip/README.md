# UAV Sidewalk Segmentation

## Cấu hình đã chọn

Hệ thống dùng một phương pháp: **Mask2Former Swin-Large Mapillary + tracking**.
Không dùng PIDNet/SegFormer, torch.compile/TensorRT, AI bất đồng bộ hoặc encoder
bất đồng bộ. Các script và preset thử nghiệm đã được gỡ khỏi bản code hiện tại.

| Thành phần | Giá trị |
| --- | --- |
| Checkpoint | facebook/mask2former-swin-large-mapillary-vistas-semantic |
| Thiết bị triển khai đã thử | CUDA Tesla T4, FP16 |
| Keyframe tối đa | 8 frame, có thể chạy AI sớm nếu tracking lỗi |
| Work/output cạnh tối đa | 960 |
| Model / hậu xử lý cạnh tối đa | 768 / 768 |
| Tracking cạnh tối đa | 640 |
| Temporal smoothing | 0.3, scores được căn theo chuyển động |
| Frame step / OpenCV threads | 1 / 1 |
| Low-light preprocessing | Tắt trong gpu_t4.json |

13,62 FPS là số đo trước trên một video và môi trường cụ thể, không phải cam kết
tốc độ hoặc độ chính xác. Đầu vào 15 FPS có khoảng cập nhật AI danh định 8/15 ≈
0,53 giây; các frame trung gian truyền mask, không nhận diện độc lập. Tracking có
forward/backward, inlier, reprojection, chuyển động và vùng nhìn mới để kích hoạt
AI lại. Những kiểm tra này không bảo đảm bắt được mọi lỗi parallax hoặc che khuất.
Chưa tích hợp live/RTSP và chưa chứng minh đạt realtime 15 FPS trên mọi cảnh.

## Chạy trên Colab

1. Chạy `python -m road_sidewalk_seg.tools.package_colab` để tạo `UAV_code_optimized.zip`.
2. Upload ZIP mới lên Colab hoặc Drive/MyDrive/UAV.
3. Mở `UAV_Sidewalk_Colab.ipynb`, chọn GPU T4 và chạy từ trên xuống.
4. Nếu có nhiều ZIP khác checksum, đặt ZIP_PATH cụ thể; notebook không tự chọn
   bản khác nhau. Manifest xác nhận profile `swin-large-k8-work960`.
5. Chọn video từ máy hoặc Drive; notebook sao chép vào ổ cục bộ trước khi phân tích.
6. Kết quả có video, video_profile.json, mask_samples và run.log. Xem H.264 và
   tải video ở hai cell cuối. Chuyển H.264 không tính vào FPS phân tích.

Không cần tải PIDNet hoặc cài TensorRT. Dữ liệu, trọng số đã tải, output lịch sử và
ZIP cũ không bị xóa. Hãy dùng ZIP mới; không giải nén lại gói thử nghiệm cũ.

## Chạy bằng CLI

```powershell
python -m road_sidewalk_seg --config configs/gpu_t4.json --input "video.mp4" --headless --save-video
```

CLI mặc định cùng profile video: interval 8, work 960, model/postprocess 768,
tracking 640, smoothing 0.3, frame_step 1, cv_threads 1, mask_sample_step 30.
Có thể bỏ --input để chọn file bằng hộp thoại trên máy có GUI. Đối với CPU,
dùng `--config configs/default.json --device cpu`; không dùng FPS CPU để suy ra T4.
Cấu hình CPU cũng chỉ dùng Swin-Large, còn cấu hình ảnh tĩnh được giữ nguyên.

## Đầu ra và đo lường

- `preview.mp4`: overlay, đường biên polygon; tốc độ phát theo nguồn.
- `video_profile.json`: FPS xử lý thực, wall time, số AI/warp/fallback,
  từng stage, thiết bị, precision và phiên bản thực tế.
- `mask_samples/`: mẫu mask mỗi 30 source frame để kiểm tra.
- Ảnh tĩnh: overlay, mask/polygon và các đầu ra hiện có của pipeline.
- `quality_verified=false` nghĩa là chưa có đánh giá nhãn chuẩn, không tự động
  phê duyệt độ chính xác chỉ vì FPS cao.
- Điểm polygon nằm trong hệ tọa độ work/output; không phải tự động tọa độ ảnh 4K.
  Tùy chọn GIS chỉ có ý nghĩa khi raster có thông tin georeferencing hợp lệ.
- GIS là tùy chọn: cài `requirements-gis.txt` khi cần; không bắt buộc cho video.

Các bước giảm nhiễu, hoàn thiện vùng che khuất, polygon hóa và kiểm tra tracking
được giữ nguyên. Phần bề mặt bị che khuất là suy đoán hình học, không phải bằng
chứng model quan sát được phần nền phía dưới.



## Cấu trúc mã nguồn

```text
road_sidewalk_seg/
├── __init__.py              API công khai: PipelineConfig, SidewalkPipeline
├── __main__.py              python -m road_sidewalk_seg
├── app/cli.py               Tham số CLI, chọn input, điều phối tác vụ
├── core/
│   ├── config.py            Dataclass và kiểm tra cấu hình
│   └── pipeline.py          Quy trình phân đoạn ảnh/frame
├── models/
│   ├── backend.py           Nạp và chạy Swin-Large
│   ├── cpu_attention.py     Attention tùy chọn cho CPU
│   └── taxonomy.py          Ánh xạ nhãn sidewalk
├── inference/
│   ├── preprocessing.py     Chuẩn bị ảnh
│   ├── predictor.py         Suy luận và quyết định mask
│   └── tiling.py            Chia tile và blending
├── postprocessing/
│   ├── completion.py        Hoàn thiện mask
│   ├── polygonization.py    Mask ↔ polygon
│   └── visualization.py     Overlay và biên
├── media/
│   ├── image_io.py          Đọc ảnh/raster
│   └── video.py             Đọc, phân tích và xuất video/profile
├── tracking/motion.py       Căn chuyển động, truyền mask/polygon
├── gis/georeference.py      Đổi tọa độ địa lý khi có metadata
└── tools/package_colab.py   Đóng gói code cho Colab
```

Mỗi thư mục có `__init__.py`; import nội bộ dùng đường dẫn package rõ ràng.
Không đổi thuật toán hoặc cấu hình đã chọn. Entry point CLI vẫn giữ nguyên.
API ngoài package: `from road_sidewalk_seg import PipelineConfig, SidewalkPipeline`.
Các đường dẫn module phẳng cũ không còn sử dụng; ví dụ import cấu hình trực tiếp
nay là `from road_sidewalk_seg.core.config import PipelineConfig`.

