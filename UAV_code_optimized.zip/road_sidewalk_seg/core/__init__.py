"""Pipeline orchestration and configuration."""
