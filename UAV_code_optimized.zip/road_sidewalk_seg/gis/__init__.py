"""Optional georeferencing support."""
