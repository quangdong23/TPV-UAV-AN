"""Sparse optical flow and camera compensation, following road_sidewalk_seg's
forward/backward consistency + RANSAC approach. No segmentation dependency.
"""
import cv2
import numpy as np


def gray_frame(frame, max_side=640):
    h, w = frame.shape[:2]
    scale = min(1., max_side / max(h, w)) if max_side else 1.
    size = (max(1, round(w * scale)), max(1, round(h * scale)))
    gray = cv2.cvtColor(cv2.resize(frame, size), cv2.COLOR_BGR2GRAY)
    return gray


def warp_box(box, matrix):
    x1, y1, x2, y2 = box
    corners = np.array([[[x1, y1], [x2, y1], [x2, y2], [x1, y2]]], np.float32)
    points = cv2.transform(corners, matrix)[0]
    return np.r_[points.min(0), points.max(0)]


class CameraMotion:
    def __init__(self, max_side=640):
        self.max_side = max_side
        self.previous = None

    def update(self, frame, boxes):
        current = gray_frame(frame, self.max_side)
        identity = np.eye(2, 3, dtype=np.float64)
        result = {'matrix': identity, 'local_boxes': {}, 'reliable': False,
                  'scene_cut': False, 'reason': 'initial'}
        previous, self.previous = self.previous, current
        if previous is None or previous.shape != current.shape:
            return result
        difference = np.mean(cv2.absdiff(previous, current)) / 255.
        hist_a = cv2.calcHist([previous], [0], None, [32], [0, 256])
        hist_b = cv2.calcHist([current], [0], None, [32], [0, 256])
        hist_distance = cv2.compareHist(hist_a, hist_b, cv2.HISTCMP_BHATTACHARYYA)
        if difference > .30 and hist_distance > .5:
            result.update(scene_cut=True, reason='scene_cut')
            return result
        h, w = frame.shape[:2]
        sx, sy = current.shape[1] / w, current.shape[0] / h

        def corners(mask, count):
            return cv2.goodFeaturesToTrack(previous, maxCorners=count, qualityLevel=.01,
                                          minDistance=5, mask=mask, blockSize=5)

        background = np.full_like(previous, 255)
        regions = {}
        for track_id, box in boxes.items():
            b = np.asarray(box) * [sx, sy, sx, sy]
            x1, y1 = np.maximum(0, np.floor(b[:2]).astype(int))
            x2, y2 = np.minimum([current.shape[1], current.shape[0]], np.ceil(b[2:]).astype(int))
            if x2 <= x1 or y2 <= y1:
                continue
            background[y1:y2, x1:x2] = 0
            # Detect ROI corners on the small patch, not the entire frame N times.
            points = cv2.goodFeaturesToTrack(previous[y1:y2, x1:x2], maxCorners=40,
                                             qualityLevel=.01, minDistance=5, blockSize=5)
            if points is not None and len(points) >= 4:
                regions[track_id] = points + np.array([x1, y1], np.float32)
        background_points = corners(background, 400)
        groups = ([(-1, background_points)] if background_points is not None else []) + list(regions.items())
        pair = None
        per_track = {}
        if groups:
            points = np.concatenate([p for _, p in groups]).astype(np.float32)
            next_points, status, _ = cv2.calcOpticalFlowPyrLK(previous, current, points, None,
                                                            winSize=(21, 21), maxLevel=3)
            if next_points is not None and status is not None:
                back, back_status, _ = cv2.calcOpticalFlowPyrLK(current, previous, next_points, None,
                                                              winSize=(21, 21), maxLevel=3)
                if back is not None and back_status is not None:
                    valid = ((status.ravel() == 1) & (back_status.ravel() == 1)
                             & (np.linalg.norm((back - points).reshape(-1, 2), axis=1) < 1.)
                             & np.isfinite(next_points.reshape(-1, 2)).all(1))
                    offset = 0
                    for key, group in groups:
                        span = slice(offset, offset + len(group))
                        good = valid[span]
                        item = (points[span].reshape(-1, 2)[good],
                                next_points[span].reshape(-1, 2)[good])
                        if key == -1:
                            pair = item
                        else:
                            per_track[key] = item
                        offset += len(group)
        if pair is not None and len(pair[0]) >= 12:
            a, b = pair
            cv2.setRNGSeed(0)  # Reproducible after restoring a checkpoint.
            matrix, inliers = cv2.estimateAffinePartial2D(a, b, method=cv2.RANSAC,
                                                       ransacReprojThreshold=2.)
            if matrix is not None and inliers is not None and np.isfinite(matrix).all():
                good = inliers.ravel().astype(bool)
                coverage = cv2.contourArea(cv2.convexHull(a[good])) / current.size if good.sum() >= 3 else 0
                scale = np.hypot(matrix[0, 0], matrix[1, 0])
                if good.sum() >= 10 and good.mean() >= .55 and coverage > .015 and .80 < scale < 1.25:
                    scaling = np.diag([sx, sy, 1.])
                    affine = np.eye(3)
                    affine[:2] = matrix
                    result.update(matrix=(np.linalg.inv(scaling) @ affine @ scaling)[:2],
                                  reliable=True, reason='tracked')
        if not result['reliable']:
            result['reason'] = 'camera_flow_unreliable'
        # Independent foreground flow is essential for moving people/vehicles.
        for track_id, box in boxes.items():
            pair = per_track.get(track_id)
            if pair is None or len(pair[0]) < 4:
                continue
            a, b = pair
            delta = b - a
            median = np.median(delta, axis=0)
            good = np.linalg.norm(delta - median, axis=1) < 2.
            if good.sum() < 4 or good.mean() < .6:
                continue
            shift = np.median(delta[good], axis=0) / [sx, sy]
            local = np.asarray(box, float) + np.tile(shift, 2)
            result['local_boxes'][track_id] = local
        return result
