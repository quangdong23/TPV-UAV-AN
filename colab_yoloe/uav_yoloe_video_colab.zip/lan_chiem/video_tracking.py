"""Class-aware Kalman/Hungarian baseline with GMC and foreground flow.

This is a lightweight tracker, not an implementation of BoT-SORT/ReID.
Only actual detections confirm tracks; flow never creates a new identity.
"""
import numpy as np
from scipy.optimize import linear_sum_assignment
from lan_chiem.video_motion import warp_box


def measurement(box):
    b = np.asarray(box, float)
    return np.r_[(b[:2] + b[2:]) / 2, np.maximum(1., b[2:] - b[:2])]


def bbox(state):
    center, size = state[:2], np.maximum(1., state[2:4])
    return np.r_[center - size / 2, center + size / 2]


def iou(a, b):
    intersection = np.maximum(0., np.minimum(a[2:], b[2:]) - np.maximum(a[:2], b[:2])).prod()
    union = np.maximum(0., a[2:] - a[:2]).prod() + np.maximum(0., b[2:] - b[:2]).prod() - intersection
    return float(intersection / max(union, 1e-6))


# Nhóm các lớp đối tượng tương đồng dễ dao động nhãn do góc nhìn UAV:
# 4: bàn nhựa, 5: ghế nhựa
# 6: xe đẩy bán hàng, 10: hàng hóa
# 7: biển quảng cáo, 8: cột điện, 9: thân cây
COMPATIBLE_CLASSES = {
    4: {4, 5},
    5: {4, 5},
    6: {6, 10},
    10: {6, 10},
    7: {7, 8},
    8: {7, 8, 9},
    9: {8, 9},
}


def association_costs(tracks, detections):
    costs=np.full((len(tracks),len(detections)),1e6)
    if not costs.size:
        return costs
    state=np.stack([t['x'][:4] for t in tracks])
    boxes=np.stack([bbox(t['x']) for t in tracks])
    target=np.stack([measurement(d['bbox_xyxy']) for d in detections])
    observed=np.array([d['bbox_xyxy'] for d in detections],float)
    intersection=np.maximum(0.,np.minimum(boxes[:,None,2:],observed[None,:,2:])
                            -np.maximum(boxes[:,None,:2],observed[None,:,:2])).prod(-1)
    union=np.maximum(0.,boxes[:,2:]-boxes[:,:2]).prod(-1)[:,None]+np.maximum(0.,observed[:,2:]-observed[:,:2]).prod(-1)[None,:]-intersection
    overlap=intersection/np.maximum(union,1e-6)
    distance=np.linalg.norm(target[None,:,:2]-state[:,None,:2],axis=-1)/np.maximum(np.linalg.norm(state[:,2:4],axis=-1),1.)[:,None]
    size_change=np.abs(np.log(target[None,:,2:4]/np.maximum(state[:,None,2:4],1.))).max(-1)
    
    t_cids = np.array([t['class_id'] for t in tracks])
    d_cids = np.array([d['class_id'] for d in detections])
    same_class = t_cids[:, None] == d_cids[None, :]

    compat = np.zeros_like(same_class, dtype=bool)
    for i, tc in enumerate(t_cids):
        allowed = COMPATIBLE_CLASSES.get(tc, {tc})
        for j, dc in enumerate(d_cids):
            if dc in allowed:
                compat[i, j] = True

    valid = compat & (size_change < .8) & ((overlap >= .1) | (distance <= .75))
    penalty = np.where(same_class, 0.0, 0.15)
    costs[valid] = (1 - overlap + .2 * distance + penalty)[valid]
    return costs


class ObjectTracker:
    def __init__(self, min_hits=2, max_lost_seconds=1., max_prediction_seconds=.5):
        self.min_hits = min_hits
        self.max_lost_seconds = max_lost_seconds
        self.max_prediction_seconds = max_prediction_seconds
        self.next_id = 1
        self.tracks = []
        self.confirmed_ids = set()
        self.events = []

    def boxes(self):
        return {t['id']: bbox(t['x']) for t in self.tracks}

    @staticmethod
    def correct(t, box, noise):
        z = measurement(box)
        p = t['p']
        gain = np.linalg.solve(p[:4, :4] + np.eye(4) * noise, p[:4, :]).T
        t['x'] += gain @ (z - t['x'][:4])
        # Joseph form preserves a positive covariance under repeated updates.
        residual = np.eye(8)
        residual[:, :4] -= gain
        t['p'] = residual @ p @ residual.T + noise * gain @ gain.T

    def update(self, timestamp, detections, motion):
        self.events = []
        def event(t, state, reason):
            self.events.append({'track_id': t['id'], 'class_id': t['class_id'],
                                'track_state': state, 'reason': reason})
        if motion['scene_cut']:
            for t in self.tracks:
                event(t, 'ended', 'scene_cut')
            self.tracks = []  # IDs remain globally unique within the video.
        for t in self.tracks:
            if timestamp - t['last_detection'] > self.max_lost_seconds:
                event(t, 'ended', 'detection_timeout')
        self.tracks = [t for t in self.tracks if timestamp - t['last_detection'] <= self.max_lost_seconds]
        for t in self.tracks:
            dt = max(0., timestamp - t['timestamp'])
            matrix = motion['matrix']
            if motion['reliable']:
                t['x'][:4] = measurement(warp_box(bbox(t['x']), matrix))
                scale = np.hypot(matrix[0, 0], matrix[1, 0])
                transform = np.eye(8)
                transform[:2, :2] = matrix[:, :2]
                transform[4:6, 4:6] = matrix[:, :2]
                for index in (2, 3, 6, 7):
                    transform[index, index] = scale
                t['x'][4:] = transform[4:, 4:] @ t['x'][4:]
                t['p'] = transform @ t['p'] @ transform.T
            transition = np.eye(8)
            transition[:4, 4:] = np.eye(4) * dt
            t['x'] = transition @ t['x']
            t['p'] = transition @ t['p'] @ transition.T + np.eye(8) * max(dt, .001) * 4
            t['timestamp'] = timestamp
            t['source'] = 'prediction'
            if t['id'] in motion['local_boxes']:
                self.correct(t, motion['local_boxes'][t['id']], 16.)
                t['source'] = 'optical_flow'
        if detections is not None:
            detections = [d for d in detections if d.get('class_id') is not None
                          and not d.get('candidate_class_ids') and d.get('status', 'predicted') == 'predicted'
                          and np.isfinite(d['bbox_xyxy']).all()
                          and np.all(np.asarray(d['bbox_xyxy'])[2:] > np.asarray(d['bbox_xyxy'])[:2])]
            costs = association_costs(self.tracks, detections)
            matched_tracks, matched_dets = set(), set()
            if costs.size:
                rows, cols = linear_sum_assignment(costs)
                for a, b in zip(rows, cols):
                    if costs[a, b] >= 1e5:
                        continue
                    t, d = self.tracks[a], detections[b]
                    self.correct(t, d['bbox_xyxy'], 4.)
                    t.update(last_detection=timestamp, hits=t['hits'] + 1,
                             score=float(d['score']), source='detection',
                             missed_detection=False, miss_count=0)
                    if int(d['class_id']) == t['class_id'] or float(d['score']) >= t['score']:
                        t['class_id'] = int(d['class_id'])
                        t['class_name_vi'] = d.get('class_name_vi', str(d['class_id']))
                    matched_tracks.add(a)
                    matched_dets.add(b)
            is_empty_scene = (len(detections) == 0)
            for a, t in enumerate(self.tracks):
                if a not in matched_tracks:
                    t['miss_count'] = t.get('miss_count', 0) + 1
                    if is_empty_scene or t['miss_count'] >= 2:
                        t['missed_detection'] = True
            for b, d in enumerate(detections):
                if b in matched_dets:
                    continue
                self.tracks.append({'id': self.next_id, 'class_id': int(d['class_id']),
                                    'class_name_vi': d.get('class_name_vi', str(d['class_id'])),
                                    'x': np.r_[measurement(d['bbox_xyxy']), np.zeros(4)],
                                    'p': np.diag([10.] * 4 + [100.] * 4), 'timestamp': timestamp,
                                    'last_detection': timestamp, 'hits': 1, 'score': float(d['score']),
                                    'source': 'detection', 'missed_detection': False, 'miss_count': 0,
                                    'smooth_box': np.asarray(d['bbox_xyxy'], float)})
                self.next_id += 1
        output = []
        for t in self.tracks:
            if t['hits'] >= self.min_hits:
                self.confirmed_ids.add(t['id'])
            age = timestamp - t['last_detection']
            state = ('tentative' if t['hits'] < self.min_hits else
                     'lost' if t.get('missed_detection', False) or age > self.max_prediction_seconds else 'active')
            if t.get('reported_state') != state:
                event(t, state, 'detector_or_motion_update')
                t['reported_state'] = state
            # No detector call != detector called and found nothing.
            if (t['hits'] < self.min_hits or t.get('missed_detection', False)
                    or age > self.max_prediction_seconds):
                continue
            curr_b = bbox(t['x'])
            if 'smooth_box' not in t or t['smooth_box'] is None:
                t['smooth_box'] = curr_b.copy()
            else:
                alpha = 0.75  # 75% current box, 25% previous box for anti-jitter
                t['smooth_box'] = alpha * curr_b + (1.0 - alpha) * t['smooth_box']
            output.append({'track_id': t['id'], 'class_id': t['class_id'],
                           'class_name_vi': t['class_name_vi'], 'bbox_xyxy': t['smooth_box'].tolist(),
                           'detection_score': t['score'], 'last_detection_timestamp': t['last_detection'],
                           'position_source': t['source'], 'track_state': 'active'})
        return output

    def state_dict(self):
        tracks = [{**t, 'x': t['x'].tolist(), 'p': t['p'].tolist(),
                   'smooth_box': (t['smooth_box'].tolist() if isinstance(t.get('smooth_box'), np.ndarray)
                                  else t.get('smooth_box', bbox(t['x']).tolist()))} for t in self.tracks]
        return {'tracks': tracks, 'next_id': self.next_id, 'confirmed_ids': sorted(self.confirmed_ids)}

    def load_state_dict(self, state):
        self.tracks = [{**t, 'x': np.asarray(t['x'], float), 'p': np.asarray(t['p'], float),
                        'smooth_box': np.asarray(t['smooth_box'], float) if 'smooth_box' in t and t['smooth_box'] is not None else bbox(np.asarray(t['x'], float))} for t in state['tracks']]
        self.next_id = state['next_id']
        self.confirmed_ids = set(state['confirmed_ids'])
