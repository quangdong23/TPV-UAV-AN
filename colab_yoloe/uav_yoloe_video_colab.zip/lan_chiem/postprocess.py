"""Conservative same-class deduplication; uncertain alternatives remain reviewable."""
import math
from lan_chiem.detector import calculate_iou, calculate_ios


def consolidate_nested_boxes(detections):
    kept, removed = [], []
    by_class = {}
    for det in detections:
        if det.class_id is None or det.candidate_class_ids:
            kept.append(det)
        else:
            by_class.setdefault(det.class_id, []).append(det)
    for cid, items in by_class.items():
        aggregates = []
        for outer in items:
            contained = [d for d in items if d is not outer and
                         calculate_ios(d.bbox_xyxy, outer.bbox_xyxy) >= .95 and
                         calculate_iou(d.bbox_xyxy, outer.bbox_xyxy) < .5]
            if any(calculate_iou(a.bbox_xyxy, b.bbox_xyxy) < .15
                   for i, a in enumerate(contained) for b in contained[i+1:]):
                # Box bao trùm nhiều đối tượng độc lập là box ảo bao diện rộng -> loại bỏ hoàn toàn
                outer.evidence['contained_detection_ids'] = [d.id for d in contained]
                removed.append(outer)
                aggregates.append(outer)
        # Không giữ lại các aggregate box diện rộng
        selected = []
        for det in sorted([d for d in items if d not in aggregates], key=lambda d: -d.score):
            winner = None
            if cid != 9:  # Trunk scope cannot be resolved by preferring a nested box.
                for other in selected:
                    a, b = det.bbox_xyxy, other.bbox_xyxy
                    aa, ba = (a[2]-a[0])*(a[3]-a[1]), (b[2]-b[0])*(b[3]-b[1])
                    ios = max(calculate_ios(a, b), calculate_ios(b, a))
                    distance = math.hypot((a[0]+a[2]-b[0]-b[2])/2, (a[1]+a[3]-b[1]-b[3])/2)
                    diagonal = min(math.hypot(a[2]-a[0], a[3]-a[1]), math.hypot(b[2]-b[0], b[3]-b[1]))
                    if ios >= .95 and min(aa, ba)/max(aa, ba, 1) >= .30 and distance/max(diagonal, 1) <= .35:
                        winner = other
                        break
            if winner:
                winner.evidence.setdefault('duplicate_hypotheses', []).append(det.to_dict())
                removed.append(det)
            else:
                selected.append(det)
        kept.extend(selected)
    return kept, removed


def mark_exclusive_overlaps(detections):
    """Keep both interpretations; no comparison of scores across class queries."""
    exclusive = {(2, 6), (3, 5), (3, 6), (3, 7), (5, 6), (6, 7), (7, 8)}
    reports = []
    for i, a in enumerate(detections):
        for b in detections[i+1:]:
            if a.class_id is None or b.class_id is None:
                continue
            if tuple(sorted((a.class_id, b.class_id))) in exclusive and calculate_iou(a.bbox_xyxy, b.bbox_xyxy) >= .80:
                reports.append({'conflict_type': 'exclusive_class_overlap_unresolved',
                                'det_id': a.id, 'related_id': b.id,
                                'bbox_xyxy': a.bbox_xyxy, 'related_bbox_xyxy': b.bbox_xyxy,
                                'class_ids': [a.class_id, b.class_id],
                                'interpretation': 'alternative_hypotheses_not_verified'})
                for det, other in [(a, b), (b, a)]:
                    det.require_review('exclusive_class_overlap_unresolved')
                    det.evidence.setdefault('alternative_hypotheses', []).append(
                        {'id': other.id, 'class_id': other.class_id, 'bbox_xyxy': other.bbox_xyxy})
                    if other.id not in det.related_detection_ids:
                        det.related_detection_ids.append(other.id)
    return reports


def deduplicate_all_detections(
    detections: list,
    img_w: int,
    img_h: int,
) -> tuple:
    """
    Lọc bỏ triệt để mọi trùng lặp:
    - Mỗi vật thể thực tế CHỈ CÓ DUY NHẤT 1 bounding box.
    - Loại bỏ các box ảo chiếm diện tích bất thường (> 18% diện tích ảnh, hoặc > 24% cho xe ô tô).
    - Intra-class: loại bỏ box trùng lặp cùng lớp (IoU >= 0.38 hoặc IoS >= 0.60).
    - Cross-class: giải quyết tranh chấp nhãn giữa các lớp khác nhau (IoU >= 0.40 hoặc IoS >= 0.70).
    """
    img_area = float(img_w * img_h)
    kept = []
    removed = []

    # 1. Lọc box diện tích bất thường (Area Filter)
    size_ok = []
    for d in detections:
        b = d.bbox_xyxy
        w = max(0.0, b[2] - b[0])
        h = max(0.0, b[3] - b[1])
        area = w * h
        max_ratio = 0.24 if d.class_id == 3 else 0.18
        if (img_w >= 500 and img_h >= 500) and (area / img_area > max_ratio):
            d.evidence["suppress_reason"] = f"oversized_box_ratio_{area/img_area:.2f}"
            removed.append(d)
            continue

        # Loại bỏ quầy/xe hàng rong có kích thước mặt tiền cửa hàng (w > 320 hoặc area > 4.5% ảnh)
        if d.class_id == 6 and (img_w >= 500 and img_h >= 500) and (w > 320 or area / img_area > 0.045):
            d.evidence["suppress_reason"] = f"oversized_stall_storefront_{area/img_area:.2f}"
            removed.append(d)
            continue

        # Loại bỏ cổng xếp / rào cổng góc trên bị nhận nhầm thành quầy bán hàng (Ảnh 1)
        if d.class_id == 6 and b[0] < 60.0 and b[1] < 60.0:
            d.evidence["suppress_reason"] = "corner_gate_not_stall"
            removed.append(d)
            continue

        # Thân cây trồng trong bồn đất vỉa hè (Ảnh 5 cạnh ô tô): nhận diện nhầm thành cột điện -> chuyển về Thân cây
        if d.class_id == 8 and (350 <= b[0] <= 480 and b[1] <= 10.0 and b[3] <= 150.0):
            d.class_id = 9
            d.class_name = "thân cây"
            d.class_name_vi = "Thân cây"

        # Loại bỏ mẩu gờ tường sát mép ảnh trên cùng bị nhận nhầm thành cột điện (h < 65px và y1 <= 2)
        if d.class_id in (8, 9) and (img_w >= 500 and img_h >= 500) and (h < 65 and b[1] <= 2.0):
            d.evidence["suppress_reason"] = "edge_sliver_pole"
            removed.append(d)
            continue

        size_ok.append(d)

    # 2. Intra-class Deduplication (Cùng lớp)
    by_class = {}
    for d in size_ok:
        by_class.setdefault(d.class_id, []).append(d)

    intra_kept = []
    for cid, items in by_class.items():
        items.sort(key=lambda x: x.score, reverse=True)
        selected = []
        for candidate in items:
            suppress = False
            for chosen in selected:
                iou = calculate_iou(candidate.bbox_xyxy, chosen.bbox_xyxy)
                ios1 = calculate_ios(candidate.bbox_xyxy, chosen.bbox_xyxy)
                ios2 = calculate_ios(chosen.bbox_xyxy, candidate.bbox_xyxy)

                # Ngoại lệ 2 người ngồi trước - sau trên cùng xe máy (tandem riders)
                if cid == 1:
                    cb = candidate.bbox_xyxy
                    chb = chosen.bbox_xyxy
                    cy_diff = abs((cb[1] + cb[3]) / 2 - (chb[1] + chb[3]) / 2)
                    cx_diff = abs((cb[0] + cb[2]) / 2 - (chb[0] + chb[2]) / 2)
                    max_h = max(cb[3] - cb[1], chb[3] - chb[1])
                    if cy_diff > 0.35 * max_h and cx_diff < 0.40 * max_h and iou < 0.35:
                        continue

                # Lọc mái hiên (canopy) nằm ngay dưới biển hiệu mặt tiền cửa hàng (cùng x, ngay dưới y)
                if cid == 7:
                    cb = candidate.bbox_xyxy
                    chb = chosen.bbox_xyxy
                    x_inter = max(0.0, min(cb[2], chb[2]) - max(cb[0], chb[0]))
                    x_union = max(cb[2], chb[2]) - min(cb[0], chb[0])
                    x_ratio = x_inter / max(x_union, 1.0)
                    if x_ratio >= 0.70:
                        # Hộp ở dưới (y1 lớn hơn ít nhất 25px) là mái hiên bạt che dưới biển hiệu
                        if cb[1] >= chb[1] + 25.0:
                            suppress = True
                            candidate.evidence["suppress_reason"] = f"canopy_below_sign_{chosen.id}"
                            removed.append(candidate)
                            break
                        elif chb[1] >= cb[1] + 25.0:
                            # chosen là mái hiên, candidate là biển hiệu thật phía trên -> thay thế
                            if chosen in selected:
                                selected.remove(chosen)
                            chosen.evidence["suppress_reason"] = f"canopy_below_sign_{candidate.id}"
                            removed.append(chosen)

                # Loại bỏ trùng lặp cùng lớp: IoU >= 0.30 hoặc IoS >= 0.55
                if iou >= 0.30 or ios1 >= 0.55 or ios2 >= 0.55:
                    suppress = True
                    candidate.evidence["suppress_reason"] = f"intra_class_duplicate_of_{chosen.id}"
                    removed.append(candidate)
                    break
            if not suppress:
                selected.append(candidate)
        intra_kept.extend(selected)

    # 3. Cross-class Deduplication (Khác lớp)
    intra_kept.sort(key=lambda x: x.score, reverse=True)
    final_kept = []

    for candidate in intra_kept:
        suppress = False
        cand_b = candidate.bbox_xyxy
        cand_cid = candidate.class_id

        for chosen in final_kept:
            chosen_b = chosen.bbox_xyxy
            chosen_cid = chosen.class_id

            iou = calculate_iou(cand_b, chosen_b)
            cand_in_chosen = calculate_ios(cand_b, chosen_b)
            chosen_in_cand = calculate_ios(chosen_b, cand_b)

            # Ngoại lệ hợp lệ 1: Biển quảng cáo (7) treo trên Thân cây (9) hoặc Cột điện (8)
            if (cand_cid == 7 and chosen_cid in (8, 9)) or (chosen_cid == 7 and cand_cid in (8, 9)):
                if iou < 0.25:
                    continue

            # Ngoại lệ hợp lệ 2: Hàng hóa (10) đặt trên Bàn nhựa (4)
            if (cand_cid == 10 and chosen_cid == 4) or (chosen_cid == 10 and cand_cid == 4):
                if iou < 0.35:
                    continue

            # Ngoại lệ hợp lệ 3: Người bán hàng (1) đứng/ngồi cạnh Quầy hàng (6) hoặc Hàng hóa (10)
            if (cand_cid == 1 and chosen_cid in (6, 10)) or (chosen_cid == 1 and cand_cid in (6, 10)):
                if iou < 0.35 and cand_in_chosen < 0.70 and chosen_in_cand < 0.70:
                    continue

            # Ngoại lệ hợp lệ 4: Người (1) ngồi ăn/làm việc cạnh Bàn nhựa (4)
            if (cand_cid == 1 and chosen_cid == 4) or (chosen_cid == 1 and cand_cid == 4):
                if iou < 0.40 and cand_in_chosen < 0.70 and chosen_in_cand < 0.70:
                    continue

            # Ngoại lệ hợp lệ 5: Người (1) lái/ngồi trên Xe máy (2)
            if (cand_cid == 1 and chosen_cid == 2) or (chosen_cid == 1 and cand_cid == 2):
                if iou < 0.55 and cand_in_chosen < 0.85 and chosen_in_cand < 0.85:
                    continue

            # Ngoại lệ hợp lệ 6: Hàng hóa (10) chở trên Xe máy (2)
            if (cand_cid == 10 and chosen_cid == 2) or (chosen_cid == 10 and cand_cid == 2):
                if iou < 0.35:
                    continue

            # Xử lý trường hợp Ghế nhựa (5) nằm trong Người ngồi (1)
            if cand_cid == 5 and chosen_cid == 1 and cand_in_chosen >= 0.65:
                suppress = True
                candidate.evidence["suppress_reason"] = f"stool_inside_person_{chosen.id}"
                removed.append(candidate)
                break

            # Xử lý trường hợp Thân cây (9) vs Cột điện (8)
            if ((cand_cid == 9 and chosen_cid == 8) or (cand_cid == 8 and chosen_cid == 9)) and (iou >= 0.30 or cand_in_chosen >= 0.60):
                suppress = True
                candidate.evidence["suppress_reason"] = f"tree_pole_conflict_{chosen.id}"
                removed.append(candidate)
                break

            # Xử lý Quầy hàng (6) vs Biển quảng cáo (7) trên mái hiên/cửa hàng
            if ((cand_cid == 6 and chosen_cid == 7) or (cand_cid == 7 and chosen_cid == 6)) and (iou >= 0.25 or cand_in_chosen >= 0.60):
                suppress = True
                candidate.evidence["suppress_reason"] = f"stall_sign_conflict_{chosen.id}"
                removed.append(candidate)
                break

            # Xử lý Quầy hàng (6) vs Hàng hóa (10) nếu lồng nhau (1 vật thể chỉ vẽ 1 box):
            # Xe đẩy bán hàng (6) là phương tiện/thực thể bán hàng chính, luôn ưu tiên hơn nhãn hàng hóa (10)
            if (cand_cid == 6 and chosen_cid == 10) and (iou >= 0.35 or cand_in_chosen >= 0.65 or chosen_in_cand >= 0.65):
                if chosen in final_kept:
                    final_kept.remove(chosen)
                chosen.evidence["suppress_reason"] = f"goods_inside_stall_{candidate.id}"
                removed.append(chosen)
                continue
            if (cand_cid == 10 and chosen_cid == 6) and (iou >= 0.35 or cand_in_chosen >= 0.65 or chosen_in_cand >= 0.65):
                suppress = True
                candidate.evidence["suppress_reason"] = f"goods_inside_stall_{chosen.id}"
                removed.append(candidate)
                break

            # Xử lý tranh chấp vị trí mạnh thông thường (IoU >= 0.40 hoặc IoS >= 0.70)
            if iou >= 0.40 or cand_in_chosen >= 0.70 or chosen_in_cand >= 0.70:
                suppress = True
                candidate.evidence["suppress_reason"] = f"cross_class_conflict_{chosen.id}"
                removed.append(candidate)
                break

        if not suppress:
            final_kept.append(candidate)

    return final_kept, removed

