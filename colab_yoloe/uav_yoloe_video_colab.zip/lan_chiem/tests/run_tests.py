"""Offline production-pipeline tests. --integration additionally loads cached model."""
import argparse
import importlib
import inspect
import sys
import unittest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--integration', action='store_true')
    parser.add_argument('--video', action='store_true', help='Include video tests (requires requirements-video.txt)')
    args = parser.parse_args()
    suite = unittest.TestSuite()
    modules = ['test_config', 'test_mapping', 'test_nms', 'test_conflicts',
               'test_tiling', 'test_sidewalk', 'test_regression', 'test_pipeline_evidence', 'test_compact', 'test_feature_cache']
    if args.integration:
        modules.append('test_pipeline')
    if args.video:
        modules.extend(['test_video', 'test_colab_stream', 'test_realtime'])
    for name in modules:
        module = importlib.import_module('lan_chiem.tests.' + name)
        suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
        for fn_name, fn in inspect.getmembers(module, inspect.isfunction):
            if fn_name.startswith('test_'):
                suite.addTest(unittest.FunctionTestCase(fn))
    return 0 if unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful() else 1


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    raise SystemExit(main())
