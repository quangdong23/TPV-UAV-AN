"""Check the adapter without downloading model weights."""
from types import SimpleNamespace
from unittest.mock import Mock, patch

import torch
from PIL import Image

from lan_chiem.yoloe_detector import YOLOEDetector


def test_yoloe_prompt_setup_and_image_output():
    detector = YOLOEDetector(device='cpu')
    engine = Mock()
    engine.ckpt_path = 'missing-test-weights.pt'
    engine.predict.return_value = [SimpleNamespace(boxes=SimpleNamespace(
        data=torch.tensor([[1., 2., 20., 30., .95, 0.]])))]
    with patch.dict('sys.modules', {'ultralytics': SimpleNamespace(YOLOE=Mock(return_value=engine))}):
        result = detector.predict(Image.new('RGB', (64, 64)))
        detector.load_model()
    names = [phrase for phrase, _, _ in detector.vocabulary]
    engine.get_text_pe.assert_called_once_with(names)
    engine.set_classes.assert_called_once_with(names, engine.get_text_pe.return_value)
    assert result['backend'] == 'yoloe'
    assert result['model_id'] == 'yoloe-v8s-seg.pt'
    assert result['object_detections'][0]['class_id'] == 1
    assert result['summary']['total_predicted_detections'] == 1
    assert result['_image_pil'].size == (64, 64)
    assert result['quality_verified'] is False
