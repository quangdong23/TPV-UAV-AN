"""Experimental YOLOE text-prompt backend using the shared object catalogue."""
from collections import Counter
from pathlib import Path
import time

from lan_chiem.detector import GroundingDINODetector
from lan_chiem.video_io import file_hash
from lan_chiem.world_detector import WorldDetector


class YOLOEDetector(WorldDetector):
    def __init__(self, weights='yoloe-v8s-seg.pt', device='auto', imgsz=640, config_path=None):
        super().__init__(weights, device, imgsz, config_path)
        self.config['model']['backend'] = 'yoloe'
        self.policy.config = self.config

    @property
    def device_info(self):
        return self.policy.device_info

    def load_model(self):
        if self.engine is not None:
            return
        from ultralytics import YOLOE
        engine = YOLOE(self.weights)
        engine.to(self.device)
        names = [phrase for phrase, _, _ in self.vocabulary]
        engine.set_classes(names, engine.get_text_pe(names))
        engine.model.eval()
        checkpoint = Path(getattr(engine, 'ckpt_path', None) or self.weights)
        self.revision = file_hash(checkpoint) if checkpoint.is_file() else None
        self.engine, self.model = engine, engine.model
        self._provenance = super().provenance()

    def provenance(self):
        return dict(self._provenance) if hasattr(self, '_provenance') else super().provenance()

    def predict_video_frame(self, image_input, **kwargs):
        """Avoid PNG encoding/hashing of every decoded video frame."""
        return self.predict(image_input, _video_frame=True, **kwargs)

    def predict(self, image_input, **kwargs):
        for option in ('box_threshold_override', 'text_threshold_override', 'preset',
                       'tile_size', 'overlap_ratio', 'nms_iou', 'query_mode',
                       'enable_counter_checks', 'enable_cart_merge', 'enable_leg_filter',
                       'enable_tree_filter', 'tile_small_objects_only'):
            if kwargs.get(option) is not None:
                raise ValueError(f'YOLOE trial does not support overriding {option}')
        for option in ('single_prompt', 'target_groups', 'sidewalk_regions'):
            if kwargs.get(option):
                raise ValueError(f'YOLOE trial does not support {option}')
        if kwargs.get('mode') not in (None, 'full'):
            raise ValueError('YOLOE trial supports only full-image inference')
        self.load_model()
        if kwargs.get('_video_frame'):
            image, name, digest = image_input, 'video_frame', None
        else:
            image, name, digest = GroundingDINODetector.preprocess_image(image_input)
        started = time.perf_counter()
        # Share the class thresholds and conflict rules, but use YOLOE inference.
        result = super().predict(image)
        selected = kwargs.get('target_classes')
        if selected is not None:
            for key in ('object_detections', 'review_candidates'):
                result[key] = [d for d in result[key] if d['class_id'] in selected]
        result.update(backend='yoloe', model_id=self.weights, image_name=name,
                      image_sha256=digest, image_size={'width': image.width, 'height': image.height},
                      provenance=self.provenance(), device=self.device,
                      inference_mode='full', query_mode='text_vocabulary',
                      inference_time_seconds=time.perf_counter()-started,
                      sidewalk_regions=[], _image_pil=image)
        result['summary'] = {
            'total_predicted_detections': len(result['object_detections']),
            'total_review_candidates': len(result['review_candidates']),
            'total_conflicts_detected': len(result['conflict_reports']),
            'predicted_class_counts': dict(Counter(str(d['class_id']) for d in result['object_detections'])),
            'review_class_counts': dict(Counter(str(d['class_id']) for d in result['review_candidates'])),
        }
        return result
