"""Streaming exports and resumable video segments; no video held in RAM."""
import csv
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

import cv2


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    temporary.replace(path)


def open_writer(path, fps, shape):
    h, w = shape[:2]
    size = (w + w % 2, h + h % 2)
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*'mp4v'), fps, size)
    if not writer.isOpened():
        writer.release()
        raise RuntimeError(f'Cannot create video: {path}')
    return writer


def write_frame(writer, frame):
    h, w = frame.shape[:2]
    if h % 2 or w % 2:
        frame = cv2.copyMakeBorder(frame, 0, h % 2, 0, w % 2, cv2.BORDER_REPLICATE)
    writer.write(frame)


def consolidate(output, segments):
    """Rebuild public exports only from committed segments."""
    output = Path(output)
    fields = ['frame_index', 'timestamp_seconds', 'track_id', 'class_id', 'class_name_vi',
              'x1', 'y1', 'x2', 'y2', 'detection_score', 'last_detection_timestamp',
              'position_source', 'track_state']
    json_temp = output / 'tracks.jsonl.tmp'
    csv_temp = output / 'tracks.csv.tmp'
    with json_temp.open('w', encoding='utf-8') as target, csv_temp.open('w', encoding='utf-8', newline='') as table:
        writer = csv.DictWriter(table, fieldnames=fields)
        writer.writeheader()
        for segment in segments:
            with (output / segment['records']).open(encoding='utf-8') as source:
                for line in source:
                    target.write(line)
                    record = json.loads(line)
                    for track in record['tracks']:
                        row = {k: track[k] for k in fields if k in track}
                        row.update(frame_index=record['frame_index'], timestamp_seconds=record['timestamp_seconds'])
                        row.update(zip(('x1', 'y1', 'x2', 'y2'), track['bbox_xyxy']))
                        writer.writerow(row)
    json_temp.replace(output / 'tracks.jsonl')
    csv_temp.replace(output / 'tracks.csv')
    if not segments:
        return 'no_frames'
    if shutil.which('ffmpeg') is None:
        return 'ffmpeg_missing: video available in segments/'
    # Relative generated names contain no user-supplied quoting characters.
    listing = output / 'segments' / 'concat.txt'
    listing.write_text(''.join(f"file '{Path(s['video']).name}'\n" for s in segments), encoding='utf-8')
    temporary = output / 'annotated.tmp.mp4'
    result = subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'concat',
                             '-safe', '1', '-i', str(listing), '-c', 'copy', str(temporary)],
                            capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(f'Cannot concatenate segments: {result.stderr[-2000:]}')
    temporary.replace(output / 'annotated.mp4')
    return 'annotated.mp4'
