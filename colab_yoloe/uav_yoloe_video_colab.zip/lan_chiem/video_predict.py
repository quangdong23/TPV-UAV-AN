"""Offline UAV object video inference, tracking and resumable segment exports.

python -m lan_chiem.video_predict --input video.mp4 --output outputs/video --device cuda
"""
import os
os.environ.setdefault('USE_TF', '0')
os.environ.setdefault('USE_FLAX', '0')

import argparse
from collections import Counter
from dataclasses import asdict, dataclass
import hashlib
import json
import math
import shutil
from pathlib import Path
import sys
import time

import cv2
import numpy as np
from PIL import Image
import torch
import yaml

from lan_chiem.detector import GroundingDINODetector
from lan_chiem.video_io import atomic_json, consolidate, file_hash, open_writer, write_frame
from lan_chiem.video_motion import CameraMotion, gray_frame
from lan_chiem.video_tracking import ObjectTracker
from lan_chiem.video_scheduler import detection_reason
from lan_chiem.visualization import draw_detections


@dataclass
class VideoOptions:
    keyframe_interval: int = 6
    min_detection_interval: int = 3
    weak_track_fraction: float = .5
    frame_step: int = 1
    tracking_max_side: int = 640
    work_max_side: int = 0
    min_hits: int = 2
    max_lost_seconds: float = 1.
    max_prediction_seconds: float = .5
    segment_frames: int = 120
    precision: str = 'fp32'
    log_interval: float = 0.
    preview_interval: float = 5.
    target_fps: float = 9.
    cv_threads: int = 1
    warmup_runs: int = 0
    fast_render: bool = False
    prompt_batch_size: int = 1

    def validate(self):
        for name in ('keyframe_interval', 'min_detection_interval', 'frame_step', 'min_hits', 'segment_frames', 'prompt_batch_size'):
            if not isinstance(getattr(self, name), int) or getattr(self, name) < 1:
                raise ValueError(f'{name} must be a positive integer')
        for name in ('tracking_max_side', 'work_max_side', 'cv_threads', 'warmup_runs'):
            if not isinstance(getattr(self, name), int) or getattr(self, name) < 0:
                raise ValueError(f'{name} must be a nonnegative integer')
        for name in ('max_lost_seconds', 'max_prediction_seconds', 'log_interval', 'preview_interval', 'target_fps'):
            value = getattr(self, name)
            if not math.isfinite(value) or value < 0:
                raise ValueError(f'{name} must be finite and nonnegative')
        if self.max_prediction_seconds > self.max_lost_seconds:
            raise ValueError('max_prediction_seconds must be <= max_lost_seconds')
        if self.precision not in ('fp32', 'fp16'):
            raise ValueError('precision must be fp32 or fp16')
        if not math.isfinite(self.weak_track_fraction) or not 0 < self.weak_track_fraction <= 1:
            raise ValueError('weak_track_fraction must be in (0, 1]')
        if self.prompt_batch_size > 8:
            raise ValueError('prompt_batch_size must be <=8; large caption batches can exceed GPU memory')


def render(frame, tracks, index, detector_ran, fps=0., fast=False):
    if fast:
        # OpenCV avoids full-resolution PIL conversions/font layout every frame.
        # Use canonical ID and short ASCII class labels, UTF-8 names stay in JSON/CSV.
        names = {1:'person', 2:'motorcycle', 3:'car', 4:'table', 5:'chair', 6:'cart',
                 7:'sign', 8:'pole', 9:'trunk', 10:'goods'}
        result = frame.copy()
        for track in tracks:
            x1, y1, x2, y2 = map(int, track['bbox_xyxy'])
            cv2.rectangle(result, (x1, y1), (x2, y2), (50, 220, 80), 2)
            label = f"#{track['track_id']} {names.get(track['class_id'], track['class_id'])}"
            cv2.putText(result, label, (max(0,x1), max(18,y1-4)), cv2.FONT_HERSHEY_SIMPLEX,
                        .45, (50,220,80), 1, cv2.LINE_AA)
    else:
        rows = [{**t, 'score': t['detection_score'],
                 'class_name_vi': f"ID {t['track_id']} {t['class_name_vi']}",
                 'raw_label': t['position_source']} for t in tracks]
        result = np.asarray(draw_detections(Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)), rows))
        result = cv2.cvtColor(result, cv2.COLOR_RGB2BGR)
    cv2.putText(result, f"frame {index} | {'DETECT' if detector_ran else 'TRACK'} | processing FPS {fps:.2f}", (12, 25),
                cv2.FONT_HERSHEY_SIMPLEX, .65, (0, 255, 255), 2)
    return result


def fit_work(frame, max_side):
    h, w = frame.shape[:2]
    if max_side and max(h,w) > max_side:
        ratio = max_side / max(h,w)
        return cv2.resize(frame, (max(2, round(w*ratio)), max(2, round(h*ratio))), interpolation=cv2.INTER_AREA)
    return frame


def process_video(source, output, detector, options=None, resume=False, max_frames=0, backup_dir=None):
    options = options or VideoOptions()
    options.validate()
    if max_frames < 0:
        raise ValueError('max_frames must be nonnegative')
    if options.precision == 'fp16' and not str(detector.device).startswith('cuda'):
        raise ValueError('fp16 requires CUDA; use fp32 for CPU')
    source, output = Path(source).resolve(), Path(output).resolve()
    backup_dir = Path(backup_dir).resolve() if backup_dir else None
    if backup_dir and (backup_dir == output or backup_dir.is_relative_to(output) or output.is_relative_to(backup_dir)):
        raise ValueError('backup_dir and output must be separate directories')
    if not source.is_file():
        raise FileNotFoundError(source)
    checkpoint_path = output / 'checkpoint.json'
    if not resume and output.exists() and any(output.iterdir()):
        raise ValueError('Output directory is not empty; choose a new output or --resume')
    if resume and not checkpoint_path.is_file():
        raise ValueError('No committed checkpoint to resume')
    output.mkdir(parents=True, exist_ok=True)
    (output / 'segments').mkdir(exist_ok=True)
    detector.precision = options.precision
    detector.prompt_batch_size = options.prompt_batch_size
    print(f'[prepare] source={source.name} device={detector.device} precision={options.precision}', flush=True)
    source_hash = file_hash(source)
    code_hash = hashlib.sha256(b''.join((Path(__file__).parent / name).read_bytes() for name in
        ('video_predict.py', 'video_io.py', 'video_tracking.py', 'video_motion.py',
         'detector.py', 'postprocess.py', 'feature_cache.py', 'object_classes.py',
         'registry.py', 'visualization.py', 'video_scheduler.py', 'world_detector.py', 'yoloe_detector.py'))).hexdigest()
    print('[load] Loading model; first download may take time.', flush=True)
    load_started = time.perf_counter()
    detector.load_model()
    predict_frame = getattr(detector, 'predict_video_frame', detector.predict)
    load_seconds = time.perf_counter() - load_started
    cuda = str(detector.device).startswith('cuda')
    gpu_name = torch.cuda.get_device_name() if cuda else 'CPU'
    model_device = str(next(detector.model.parameters()).device) if hasattr(getattr(detector, 'model', None), 'parameters') else str(detector.device)
    if cuda and not model_device.startswith('cuda'):
        raise RuntimeError(f'Model is on {model_device}, expected CUDA')
    print(f'[runtime] GPU={gpu_name} model_device={model_device} precision={options.precision} '
          f'model_load={load_seconds:.2f}s keyframe={options.keyframe_interval} '
          f'min_redetect={options.min_detection_interval}', flush=True)
    signature = {'schema': 1, 'source_sha256': source_hash, 'code_sha256': code_hash,
                 'video_options': asdict(options), 'detector_config': detector.config,
                 'device': str(detector.device),
                 'model_revision': detector.provenance().get('model_revision'),
                 'versions': {'torch': torch.__version__, 'opencv': cv2.__version__,
                              'transformers': detector.provenance()['versions']['transformers']}}
    # JSON normalization handles YAML integer keys consistently on resume.
    signature = json.loads(json.dumps(signature))
    state = json.loads(checkpoint_path.read_text(encoding='utf-8')) if resume else None
    if state and state['signature'] != signature:
        raise ValueError('Resume rejected: source, code, environment or configuration changed')
    capture = cv2.VideoCapture(str(source))
    if not capture.isOpened():
        raise RuntimeError(f'Cannot open video: {source}')
    fps = capture.get(cv2.CAP_PROP_FPS)
    source_frames = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
    if not math.isfinite(fps) or fps <= 0:
        capture.release()
        raise ValueError('Video FPS unavailable; normalize video before processing')
    tracker = ObjectTracker(options.min_hits, options.max_lost_seconds, options.max_prediction_seconds)
    motion = CameraMotion(options.tracking_max_side)
    index = state['next_frame'] if state else 0
    total = state['processed_frames'] if state else 0
    last_detection_index = state['last_detection_index'] if state else -10**9
    last_detection_timestamp = state['last_detection_timestamp'] if state else -1e9
    last_timestamp = state['last_timestamp'] if state else -1.
    segments = state['segments'] if state else []
    counts = Counter(state['counts'] if state else {})
    timings = Counter(state['stage_seconds'] if state else {})
    timings['model_load'] += load_seconds
    prior_wall = state['wall_seconds'] if state else 0.
    writer = records = None
    segment_count, current_count = 0, 0
    started = time.perf_counter() - load_seconds
    last_log = started
    last_preview = -1e9
    frame_latencies = []
    warmup_seconds = 0.
    ended = False
    frame = None
    frame_shape = None

    def backup_checkpoint():
        if backup_dir is None:
            return
        (backup_dir / 'segments').mkdir(parents=True, exist_ok=True)
        # Immutable segment files first, checkpoint last: interruption never
        # points a durable checkpoint at incomplete video/track data.
        for segment in segments:
            for key in ('video', 'records'):
                name = segment[key]
                destination = backup_dir / name
                if not destination.exists() or destination.stat().st_size != (output / name).stat().st_size:
                    temporary = destination.with_suffix(destination.suffix + '.tmp')
                    shutil.copyfile(output / name, temporary)
                    temporary.replace(destination)
        shutil.copyfile(output / state['previous_frame'], backup_dir / state['previous_frame'])
        atomic_json(backup_dir / 'checkpoint.json', state)

    def commit(completed):
        nonlocal writer, records, segment_count, state
        if writer is None:
            return
        writer.release()
        records.close()
        writer = records = None
        part = len(segments)
        image_name = f'segments/previous_{part:06d}.png'
        if not cv2.imwrite(str(output / image_name), frame):
            raise RuntimeError('Cannot save checkpoint frame')
        segments.append({'video': f'segments/part_{part:06d}.mp4',
                         'records': f'segments/part_{part:06d}.jsonl', 'frames': segment_count,
                         'video_sha256': file_hash(output / f'segments/part_{part:06d}.mp4'),
                         'records_sha256': file_hash(output / f'segments/part_{part:06d}.jsonl')})
        state = {'signature': signature, 'next_frame': index, 'processed_frames': total,
                 'last_detection_index': last_detection_index, 'last_timestamp': last_timestamp,
                 'last_detection_timestamp': last_detection_timestamp,
                 'source_shape': frame_shape,
                 'segments': segments, 'tracker': tracker.state_dict(), 'previous_frame': image_name,
                 'previous_frame_sha256': file_hash(output / image_name),
                 'counts': dict(counts), 'stage_seconds': dict(timings),
                 'wall_seconds': prior_wall + time.perf_counter() - started, 'completed': completed}
        atomic_json(checkpoint_path, state)
        backup_checkpoint()
        segment_count = 0

    try:
        if state:
            for part, segment in enumerate(segments):
                for key, suffix in (('video', 'mp4'), ('records', 'jsonl')):
                    expected = f'segments/part_{part:06d}.{suffix}'
                    if segment[key] != expected or file_hash(output / expected) != segment[key + '_sha256']:
                        raise ValueError('Checkpoint segment is missing, changed or corrupt')
            if state['previous_frame'] != f'segments/previous_{len(segments)-1:06d}.png':
                raise ValueError('Invalid checkpoint frame path')
            tracker.load_state_dict(state['tracker'])
            previous = cv2.imread(str(output / state['previous_frame']))
            if previous is None or file_hash(output / state['previous_frame']) != state['previous_frame_sha256']:
                raise ValueError('Checkpoint frame is missing or corrupt')
            frame_shape = tuple(state['source_shape'])
            motion.previous = gray_frame(previous, options.tracking_max_side)
            if state['completed']:
                ended = True
            elif not capture.set(cv2.CAP_PROP_POS_FRAMES, index) or abs(capture.get(cv2.CAP_PROP_POS_FRAMES) - index) > .5:
                raise RuntimeError('Cannot seek to checkpoint frame')
        previous_cv_threads = cv2.getNumThreads()
        if options.cv_threads:
            cv2.setNumThreads(options.cv_threads)
        while not ended and (max_frames == 0 or current_count < max_frames):
            frame_started = time.perf_counter()
            t = time.perf_counter()
            success, decoded = capture.read()
            timings['decode'] += time.perf_counter() - t
            if not success:
                ended = True
                break
            frame = decoded
            if frame_shape is not None and frame.shape != frame_shape:
                raise ValueError('Video frame dimensions changed; split/normalize video first')
            frame_shape = frame.shape
            original_h, original_w = frame.shape[:2]
            frame = fit_work(frame, options.work_max_side)
            if current_count == 0 and options.warmup_runs:
                warm_started = time.perf_counter()
                warm_image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                print(f'[warmup] runs={options.warmup_runs}; excluded from steady throughput, included in end-to-end', flush=True)
                for _ in range(options.warmup_runs):
                    predict_frame(warm_image, mode='full')
                if cuda:
                    torch.cuda.synchronize()
                warmup_seconds = time.perf_counter()-warm_started
                frame_started = time.perf_counter()
            timestamp = capture.get(cv2.CAP_PROP_POS_MSEC) / 1000.
            if not math.isfinite(timestamp) or timestamp <= last_timestamp:
                timestamp = max(index / fps, last_timestamp + options.frame_step / fps)
                counts['timestamp_fallbacks'] += 1
            t = time.perf_counter()
            movement = motion.update(frame, tracker.boxes())
            timings['motion'] += time.perf_counter() - t
            reason = detection_reason(index, timestamp, tracker.tracks, movement,
                                      last_detection_index, last_detection_timestamp, options)
            run_detector = reason is not None
            detections = None
            detector_seconds = 0.
            model_calls = 0
            if run_detector:
                print(f'[detect] frame={index}/{source_frames or "?"} source_time={timestamp:.2f}s reason={reason}', flush=True)
                t = time.perf_counter()
                pass_count = [0]
                def forward_progress(stat):
                    pass_count[0] += 1
                    print(f'[forward] frame={index} pass={pass_count[0]} source={stat["source"]} '
                          f'forward_s={stat["forward_seconds"]:.3f} '
                          f'cache_hit={stat["image_feature_cache_hit"]}', flush=True)
                # First detector update exposes cold-start/forward latency without
                # flooding Colab with six messages for every subsequent update.
                detector._forward_progress_callback = forward_progress if current_count == 0 else None
                try:
                    result = predict_frame(Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)), mode='full')
                    if cuda:
                        torch.cuda.synchronize()
                finally:
                    detector._forward_progress_callback = None
                detections = result['object_detections']
                # Review candidates intentionally never enter the tracker.
                detector_seconds = time.perf_counter() - t
                timings['detector'] += detector_seconds
                counts['detector_frames'] += 1
                counts['model_calls'] += result.get('model_calls', 0)
                model_calls = result.get('model_calls', 0)
                counts[f'detect_reason_{reason}'] += 1
                counts['discarded_review_candidates'] += len(result.get('review_candidates', []))
                last_detection_index = index
                last_detection_timestamp = timestamp
            else:
                counts['tracking_only_frames'] += 1
            if movement['scene_cut']:
                counts['scene_cuts'] += 1
            t = time.perf_counter()
            tracks = tracker.update(timestamp, detections, movement)
            h, w = frame.shape[:2]
            for track in tracks:
                b = track['bbox_xyxy']
                track['bbox_xyxy'] = [float(np.clip(b[0], 0, w)), float(np.clip(b[1], 0, h)),
                                     float(np.clip(b[2], 0, w)), float(np.clip(b[3], 0, h))]
            tracks = [track for track in tracks if track['bbox_xyxy'][2] > track['bbox_xyxy'][0]
                      and track['bbox_xyxy'][3] > track['bbox_xyxy'][1]]
            timings['tracking'] += time.perf_counter() - t
            t = time.perf_counter()
            if writer is None:
                part = len(segments)
                writer = open_writer(output / f'segments/part_{part:06d}.mp4', fps / options.frame_step, frame.shape)
                records = (output / f'segments/part_{part:06d}.jsonl').open('w', encoding='utf-8')
            rendered = render(frame, tracks, index, run_detector,
                              (current_count + 1) / max(time.perf_counter()-started, 1e-6), options.fast_render)
            write_frame(writer, rendered)
            frame_seconds = time.perf_counter() - frame_started
            # Tracker/video use work pixels; public data always use original pixels.
            factor = [original_w/w, original_h/h, original_w/w, original_h/h]
            exported_tracks = [{**track, 'bbox_xyxy': (np.asarray(track['bbox_xyxy'])*factor).tolist()} for track in tracks]
            record = {'frame_index': index, 'timestamp_seconds': timestamp, 'detector_ran': run_detector,
                      'coordinate_space': 'source_pixels', 'source_size': [original_w, original_h],
                      'working_size': [w,h],
                      'detection_reason': reason, 'model_calls': model_calls,
                      'frame_seconds': frame_seconds, 'processing_fps': 1 / max(frame_seconds, 1e-6),
                      'detector_seconds': detector_seconds, 'camera_motion_reliable': movement['reliable'],
                      'motion_reason': movement['reason'], 'tracks': exported_tracks, 'track_events': tracker.events}
            records.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + '\n')
            timings['render_encode_export'] += time.perf_counter() - t
            total += 1
            current_count += 1
            segment_count += 1
            index += options.frame_step
            last_timestamp = timestamp
            if segment_count >= options.segment_frames:
                commit(False)
            now = time.perf_counter()
            frame_latencies.append(now-frame_started)
            if current_count == 1 or now - last_log >= options.log_interval:
                avg_fps = current_count / max(now-started, 1e-6)
                remaining_frames = max(0, source_frames-index) / options.frame_step
                if max_frames:
                    remaining_frames = min(remaining_frames, max(0, max_frames-current_count))
                eta = remaining_frames / max(avg_fps, 1e-6)
                status = {'frame_index': index-options.frame_step, 'source_frames': source_frames,
                          'source_time_seconds': timestamp, 'processed_frames': total,
                          'frame_seconds': frame_seconds, 'frame_processing_fps': 1/max(frame_seconds, 1e-6),
                          'average_processing_fps': avg_fps, 'eta_seconds': eta,
                          'detector_seconds': detector_seconds, 'detector_ran': run_detector,
                          'detection_reason': reason, 'detector_frames': counts['detector_frames'],
                          'model_calls': counts['model_calls'], 'device': str(detector.device),
                          'gpu': gpu_name, 'precision': options.precision}
                atomic_json(output / 'status.json', status)
                print(f'[video] frame={index-options.frame_step}/{source_frames or "?"} '
                      f't={timestamp:.2f}s mode={"DETECT" if run_detector else "TRACK"} '
                      f'frame_fps={status["frame_processing_fps"]:.2f} avg_fps={avg_fps:.2f} '
                      f'detect_s={detector_seconds:.3f} AI={counts["detector_frames"]}/{total} '
                      f'calls={counts["model_calls"]} tracks={len(tracks)} ETA={eta:.0f}s', flush=True)
                last_log = now
            if options.preview_interval > 0 and now-last_preview >= options.preview_interval:
                scale = min(1., 960/max(rendered.shape[:2]))
                preview = cv2.resize(rendered, None, fx=scale, fy=scale)
                temporary = output / 'latest_preview.tmp.jpg'
                if not cv2.imwrite(str(temporary), preview, [cv2.IMWRITE_JPEG_QUALITY, 80]):
                    raise RuntimeError('Cannot write live preview')
                temporary.replace(output / 'latest_preview.jpg')
                print(f'[preview] {output / "latest_preview.jpg"}', flush=True)
                last_preview = now
            for _ in range(options.frame_step - 1):
                if not capture.grab():
                    ended = True
                    break
            if ended:
                break
        commit(ended)
        if state is None:
            raise ValueError('No decodable frames in video')
        # EOF may occur exactly at a segment boundary.
        state['completed'] = ended
        atomic_json(checkpoint_path, state)
        backup_checkpoint()
    finally:
        capture.release()
        if 'previous_cv_threads' in locals():
            cv2.setNumThreads(previous_cv_threads)
        if writer is not None:
            writer.release()
        if records is not None:
            records.close()
    final_started = time.perf_counter()
    video_status = consolidate(output, segments)
    final_seconds = time.perf_counter() - final_started
    wall = prior_wall + time.perf_counter() - started
    steady_wall = max(time.perf_counter()-started-load_seconds-warmup_seconds, 1e-6)
    steady_fps = current_count / steady_wall if current_count else None
    summary = {'source': str(source), 'source_fps': fps, 'source_sha256': source_hash,
               'processed_frames': total, 'completed': ended, 'wall_seconds': wall,
               'processed_fps': total / max(wall, 1e-6), 'finalize_seconds': final_seconds,
               'steady_pipeline_fps_this_run': steady_fps,
               'detector_fps_this_run': counts['detector_frames'] / timings['detector'] if timings['detector'] else None,
               'detector_mean_seconds_this_run': timings['detector'] / counts['detector_frames'] if counts['detector_frames'] else None,
               'ai_frame_fraction_this_run': counts['detector_frames'] / current_count if current_count else None,
               'warmup_seconds_this_run': warmup_seconds,
               'target_fps': options.target_fps,
               'throughput_target_met': bool(steady_fps is not None and steady_fps >= options.target_fps and options.frame_step == 1),
               'end_to_end_target_met': total/max(wall,1e-6) >= options.target_fps and options.frame_step == 1,
               'frame_skipping_enabled': options.frame_step > 1,
               'speed_vs_source': (last_timestamp+1/fps)/max(wall,1e-6),
               'all_source_frames_processed': bool(ended and options.frame_step == 1 and total >= source_frames and source_frames > 0),
               'latency_p95_seconds_this_run': float(np.percentile(frame_latencies,95)) if frame_latencies else None,
               'live_latency_verified': False,
               'confirmed_track_count': len(tracker.confirmed_ids), 'unique_object_count_verified': False,
               'counts': dict(counts), 'stage_seconds': dict(timings), 'video': video_status,
               'tracker': 'class-aware Kalman/Hungarian + GMC + foreground LK (no ReID)',
               'runtime': signature, 'quality_verified': False,
               'gpu': torch.cuda.get_device_name() if str(detector.device).startswith('cuda') else None,
               'peak_gpu_allocated_bytes': torch.cuda.max_memory_allocated() if str(detector.device).startswith('cuda') else None,
               'timing_note': 'End-to-end excludes source hashing and resume seek; includes model load and final exports.',
               'media_note': 'Silent CFR output at source FPS/frame_step; JSONL timestamps are authoritative for VFR.'}
    atomic_json(output / 'summary.json', summary)
    if backup_dir:
        atomic_json(backup_dir / 'summary.json', summary)
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--video-config', type=Path, default=Path(__file__).with_name('video_config.yaml'))
    parser.add_argument('--config', type=Path, help='Detector YAML; defaults to existing image config')
    parser.add_argument('--device', choices=['auto', 'cuda', 'cpu'], default='cuda')
    parser.add_argument('--backend', choices=['grounding-dino', 'world', 'yoloe'], default='grounding-dino')
    parser.add_argument('--weights', default=None)
    parser.add_argument('--imgsz', type=int, default=640)
    parser.add_argument('--cache-dir', default='.hf_cache')
    parser.add_argument('--precision', choices=['fp32', 'fp16'])
    parser.add_argument('--keyframe-interval', type=int)
    parser.add_argument('--min-detection-interval', type=int)
    parser.add_argument('--log-interval', type=float)
    parser.add_argument('--preview-interval', type=float)
    parser.add_argument('--frame-step', type=int)
    parser.add_argument('--max-frames', type=int, default=0, help='Limit frames this invocation; resume continues after them')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--backup-dir', type=Path, help='Mirror committed segments/checkpoint to Drive after each segment')
    parser.add_argument('--threads', type=int, default=2)
    args = parser.parse_args(argv)
    if args.threads < 1:
        parser.error('--threads must be positive')
    if args.device == 'cuda' and not torch.cuda.is_available():
        parser.error('CUDA unavailable. Select a GPU runtime in Colab or explicitly use --device cpu.')
    torch.set_num_threads(args.threads)
    config = yaml.safe_load(args.video_config.read_text(encoding='utf-8')) or {}
    for name in ('precision', 'keyframe_interval', 'frame_step', 'min_detection_interval', 'log_interval', 'preview_interval'):
        if getattr(args, name) is not None:
            config[name] = getattr(args, name)
    options = VideoOptions(**config)
    options.validate()
    if args.backend == 'yoloe':
        from lan_chiem.yoloe_detector import YOLOEDetector
        detector = YOLOEDetector(args.weights or 'yoloe-v8s-seg.pt', args.device, args.imgsz, args.config)
    elif args.backend == 'world':
        from lan_chiem.world_detector import WorldDetector
        detector = WorldDetector(args.weights or 'yolov8s-worldv2.pt', args.device, args.imgsz, args.config)
    else:
        detector = GroundingDINODetector(config_path=args.config, device=args.device, cache_dir=args.cache_dir)
    path = process_video(args.input, args.output, detector, options, args.resume, args.max_frames, args.backup_dir)
    print(f'[saved] {path}')
    return 0


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
